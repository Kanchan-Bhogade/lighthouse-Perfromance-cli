# lighthouse-cli
example Github executions flow :- 
{
  "inputs": {
    "projectName": "MyProject",
    "client": "ClientABC",
    "projectManager": "John Doe",
    "qaManager": "Jane Smith",
    "expectedLoadTime": "5 seconds",
    "urls": "https://www.qed42.com/about,https://www.example.com,https://www.testsite.org"
  }
}
